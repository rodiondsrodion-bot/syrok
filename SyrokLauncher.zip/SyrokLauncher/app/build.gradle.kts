plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Ссылка на манифест: файл manifest_url.txt рядом с папкой проекта (в корне GitHub-репозитория)
val manifestUrl: String = listOf(
    File(rootProject.projectDir.parentFile, "manifest_url.txt"),
    File(rootProject.projectDir, "manifest_url.txt"),
).firstOrNull { it.isFile }?.readText()?.trim()?.lineSequence()?.firstOrNull()?.trim()
    ?: "https://www.dropbox.com/scl/fi/n4tc6fl7zxbbzbdbfb6w3/servers-7.json?rlkey=zijsnin167zxgnfujfeitf20i&st=qdn0j55w&dl=1"

android {
    namespace = "com.syrok.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.syrok.launcher"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "1.3.1"
        buildConfigField("String", "MANIFEST_URL", "\"" + manifestUrl.replace("\"", "") + "\"")

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17"
                arguments += "-DANDROID_STL=c++_static"
            }
        }
    }

    // Постоянная подпись: новые версии ставятся поверх старых без удаления
    signingConfigs {
        getByName("debug") {
            storeFile = file("syrok.jks")
            storePassword = "syrok123"
            keyAlias = "syrok"
            keyPassword = "syrok123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // TODO: замени на свою подпись (keystore) перед публикацией.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
