-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.syrok.launcher.NativeBridge { *; }
-keep class com.syrok.launcher.EmbersView { <init>(...); }
