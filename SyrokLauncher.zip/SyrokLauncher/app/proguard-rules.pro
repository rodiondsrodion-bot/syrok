-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.syrok.launcher.NativeBridge { *; }
