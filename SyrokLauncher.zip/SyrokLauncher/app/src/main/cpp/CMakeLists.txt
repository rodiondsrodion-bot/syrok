cmake_minimum_required(VERSION 3.22.1)
project(syroklauncher LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(syroklauncher SHARED syrok.cpp)

find_library(log-lib log)

target_compile_options(syroklauncher PRIVATE -Wall -Wextra -fvisibility=hidden)
target_link_libraries(syroklauncher ${log-lib} dl)

# Android 15+: поддержка устройств с 16 КБ страницами памяти
target_link_options(syroklauncher PRIVATE "-Wl,-z,max-page-size=16384")
