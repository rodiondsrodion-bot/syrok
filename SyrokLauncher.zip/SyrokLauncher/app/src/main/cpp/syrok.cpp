// Syrok Role Play — JNI-мост лаунчера.
//
// Что делает по умолчанию:
//   1. nativeInit            — запоминает ник, IP/порт сервера и папку с игрой;
//   2. nativeLoadLibraries   — dlopen() скачанных игровых библиотек по порядку из манифеста,
//                              вызывает у каждой JNI_OnLoad (если есть) и опциональный
//                              SyrokGame_SetConfig(nick, ip, port, root);
//   3. nativeStart           — запускает игру через StartGame() (см. блок «ВСТАВЬ СВОЁ»).
//
// Игровая библиотека может экспортировать (все функции необязательные):
//   void SyrokGame_SetConfig(const char* nick, const char* ip, int port, const char* root);
//   int  SyrokGame_Start(JNIEnv* env, jobject activity);   // 0 = успех

#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>

#include <mutex>
#include <string>
#include <vector>

#define TAG "SyrokNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

JavaVM*    g_vm = nullptr;
std::mutex g_mutex;

struct Config {
    std::string nick;
    std::string ip;
    std::string root;
    int         port = 7777;
} g_cfg;

std::vector<void*> g_handles;

using JniOnLoadFn = jint (*)(JavaVM*, void*);
using SetConfigFn = void (*)(const char* nick, const char* ip, int port, const char* root);
using StartFn     = int  (*)(JNIEnv* env, jobject activity);

std::string ToStd(JNIEnv* env, jstring s) {
    if (!s) return {};
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

// Пустая строка -> null (в Kotlin это "ошибок нет").
jstring ToJavaOrNull(JNIEnv* env, const std::string& s) {
    return s.empty() ? nullptr : env->NewStringUTF(s.c_str());
}

template <typename Fn>
Fn FindSymbol(const char* name) {
    for (void* h : g_handles) {
        if (void* p = dlsym(h, name)) return reinterpret_cast<Fn>(p);
    }
    return nullptr;
}

// ============================================================================
//  >>> ВСТАВЬ СВОЁ <<<
//
//  Тут запускается движок игры. По умолчанию ищем в загруженных библиотеках
//  экспорт `int SyrokGame_Start(JNIEnv*, jobject activity)` и вызываем его.
//  Если у твоей игровой библиотеки другая точка входа (или нужны хуки, патчи,
//  инициализация, передача параметров) — меняй этот код как нужно.
//  Верни пустую строку при успехе или текст ошибки (он покажется в тосте).
// ============================================================================
std::string StartGame(JNIEnv* env, jobject activity) {
    auto start = FindSymbol<StartFn>("SyrokGame_Start");
    if (!start) {
        return "В загруженных библиотеках нет SyrokGame_Start. "
               "Добавь свой код запуска в StartGame() (app/src/main/cpp/syrok.cpp).";
    }
    LOGI("Запуск игры: nick=%s server=%s:%d", g_cfg.nick.c_str(), g_cfg.ip.c_str(), g_cfg.port);
    const int rc = start(env, activity);
    if (rc != 0) return "SyrokGame_Start вернул код " + std::to_string(rc);
    return {};
}

}  // namespace

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    LOGI("libsyroklauncher загружена");
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_com_syrok_launcher_NativeBridge_nativeInit(JNIEnv* env, jclass, jstring nick, jstring ip,
                                                jint port, jstring root) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_cfg.nick = ToStd(env, nick);
    g_cfg.ip   = ToStd(env, ip);
    g_cfg.port = port;
    g_cfg.root = ToStd(env, root);
}

JNIEXPORT jstring JNICALL
Java_com_syrok_launcher_NativeBridge_nativeLoadLibraries(JNIEnv* env, jclass, jobjectArray paths) {
    std::lock_guard<std::mutex> lock(g_mutex);

    const jsize n = env->GetArrayLength(paths);
    for (jsize i = 0; i < n; ++i) {
        auto* js = static_cast<jstring>(env->GetObjectArrayElement(paths, i));
        const std::string path = ToStd(env, js);
        env->DeleteLocalRef(js);

        dlerror();  // сбросить старую ошибку
        void* handle = dlopen(path.c_str(), RTLD_NOW | RTLD_GLOBAL);
        if (!handle) {
            const char* e = dlerror();
            const std::string err = "dlopen(" + path + "): " + (e ? e : "unknown error");
            LOGE("%s", err.c_str());
            return ToJavaOrNull(env, err);
        }
        g_handles.push_back(handle);
        LOGI("Загружена: %s", path.c_str());

        if (auto onLoad = reinterpret_cast<JniOnLoadFn>(dlsym(handle, "JNI_OnLoad"))) {
            const jint v = onLoad(g_vm, nullptr);
            if (v < 0) return ToJavaOrNull(env, "JNI_OnLoad вернул ошибку в " + path);
        }
        if (auto setCfg = reinterpret_cast<SetConfigFn>(dlsym(handle, "SyrokGame_SetConfig"))) {
            setCfg(g_cfg.nick.c_str(), g_cfg.ip.c_str(), g_cfg.port, g_cfg.root.c_str());
        }
    }
    return nullptr;
}

JNIEXPORT jstring JNICALL
Java_com_syrok_launcher_NativeBridge_nativeStart(JNIEnv* env, jclass, jobject activity) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return ToJavaOrNull(env, StartGame(env, activity));
}

JNIEXPORT jstring JNICALL
Java_com_syrok_launcher_NativeBridge_nativeVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF("syrok-native 1.0");
}

}  // extern "C"
