package com.syrok.launcher.net

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.syrok.launcher.data.ApkInfo
import com.syrok.launcher.data.GameStorage
import com.syrok.launcher.data.RemoteFile
import com.syrok.launcher.data.sha256Hex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/** Самообновление лаунчера: скачивает APK (с проверкой sha256) и вызывает системную установку. */
object ApkUpdater {

    suspend fun download(
        storage: GameStorage,
        info: ApkInfo,
        onProgress: (done: Long, total: Long) -> Unit,
    ): File = coroutineScope {
        val dest = File(storage.updatesDir, "syrok-${info.versionCode}.apk")

        // Выкидываем старые APK и проверяем, не скачан ли нужный уже
        val alreadyDownloaded = withContext(Dispatchers.IO) {
            storage.updatesDir.listFiles()
                ?.filter { it != dest && !it.name.endsWith(".part") }
                ?.forEach { it.delete() }
            dest.isFile && dest.length() == info.size && dest.sha256Hex().equals(info.sha256, true)
        }
        if (alreadyDownloaded) return@coroutineScope dest

        val counter = AtomicLong(File(dest.path + ".part").length())
        val ticker = launch {
            while (true) {
                onProgress(counter.get(), info.size)
                delay(300)
            }
        }
        try {
            withContext(Dispatchers.IO) {
                Net.downloadResumable(RemoteFile(dest.name, info.url, info.size, info.sha256), dest, counter)
            }
        } finally {
            ticker.cancel()
        }
        dest
    }

    /** true — системный установщик открыт; false — нужно разрешение «Установка из неизвестных источников». */
    fun install(context: Context, apk: File): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
