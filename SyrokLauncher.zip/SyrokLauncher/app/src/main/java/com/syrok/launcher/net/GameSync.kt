package com.syrok.launcher.net

import android.os.SystemClock
import com.syrok.launcher.LauncherConfig
import com.syrok.launcher.data.CacheIndex
import com.syrok.launcher.data.GameStorage
import com.syrok.launcher.data.Manifest
import com.syrok.launcher.data.RemoteFile
import com.syrok.launcher.data.sha256Hex
import com.syrok.launcher.toMegabytes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

enum class Phase { CHECKING, DOWNLOADING, DONE }

data class SyncProgress(
    val phase: Phase,
    val doneBytes: Long,
    val totalBytes: Long,
    val speedBps: Long,
    val currentFile: String,
    val filesDone: Int,
    val filesTotal: Int,
)

class NoSpaceException(message: String) : IOException(message)

/**
 * Синхронизация игровых файлов с манифестом:
 *  1. удаляет то, чего больше нет в манифесте;
 *  2. проверяет кэш (быстро — по индексу, иначе по sha256);
 *  3. проверяет место на диске;
 *  4. докачивает недостающее параллельно, с докачкой после обрыва.
 */
class GameSync(private val storage: GameStorage, private val index: CacheIndex) {

    suspend fun run(manifest: Manifest, onProgress: (SyncProgress) -> Unit) =
        withContext(Dispatchers.IO) {
            val files = manifest.files
            val totalFiles = files.size
            val totalBytes = files.sumOf { it.size }

            // 0. Чистим то, что исчезло из манифеста
            val wanted = files.map { it.path }.toSet()
            for (old in index.paths() - wanted) {
                runCatching { storage.resolve(old).delete() }
                index.remove(old)
            }

            // 1. Проверка кэша
            val pending = ArrayList<RemoteFile>()
            var okBytes = 0L
            for ((i, rf) in files.withIndex()) {
                ensureActive()
                onProgress(SyncProgress(Phase.CHECKING, okBytes, totalBytes, 0, rf.path, i, totalFiles))
                val f = storage.resolve(rf.path)
                val valid = when {
                    index.isValid(rf, f) -> true
                    f.isFile && f.length() == rf.size && f.sha256Hex().equals(rf.sha256, true) -> {
                        index.put(rf.path, f, rf.sha256)
                        true
                    }
                    else -> false
                }
                if (valid) okBytes += rf.size else pending += rf
            }
            index.save()

            if (pending.isEmpty()) {
                index.dataVersion = manifest.dataVersion
                index.save()
                onProgress(SyncProgress(Phase.DONE, totalBytes, totalBytes, 0, "", totalFiles, totalFiles))
                return@withContext
            }

            // 2. Место на диске (с запасом 50 МБ на каждый раздел)
            var partBytes = 0L
            var needInternal = 0L
            var needExternal = 0L
            for (rf in pending) {
                val dest = storage.resolve(rf.path)
                val have = minOf(File(dest.path + ".part").length(), rf.size)
                partBytes += have
                if (rf.path.endsWith(".so")) needInternal += rf.size - have else needExternal += rf.size - have
            }
            val margin = 50L * 1024 * 1024
            if (needInternal > 0 && storage.internalRoot.usableSpace < needInternal + margin) {
                throw NoSpaceException("Недостаточно места во внутренней памяти: нужно ещё ${(needInternal + margin).toMegabytes()} МБ")
            }
            if (needExternal > 0 && storage.externalRoot.usableSpace < needExternal + margin) {
                throw NoSpaceException("Недостаточно места: нужно ещё ${(needExternal + margin).toMegabytes()} МБ")
            }

            // 3. Загрузка
            val counter = AtomicLong(okBytes + partBytes)
            val filesDone = AtomicInteger(totalFiles - pending.size)
            val current = AtomicReference(pending.first().path)

            coroutineScope {
                val ticker = launch {
                    var last = counter.get()
                    var lastT = SystemClock.elapsedRealtime()
                    var speed = 0L
                    while (true) {
                        delay(300)
                        val now = counter.get()
                        val t = SystemClock.elapsedRealtime()
                        val inst = maxOf(0L, now - last) * 1000 / maxOf(1L, t - lastT)
                        speed = if (speed == 0L) inst else (speed * 7 + inst * 3) / 10
                        last = now
                        lastT = t
                        onProgress(
                            SyncProgress(
                                Phase.DOWNLOADING, now.coerceIn(0, totalBytes), totalBytes,
                                speed, current.get(), filesDone.get(), totalFiles,
                            )
                        )
                    }
                }
                val semaphore = Semaphore(LauncherConfig.PARALLEL_DOWNLOADS)
                try {
                    pending.map { rf ->
                        async {
                            semaphore.withPermit {
                                current.set(rf.path)
                                val dest = storage.resolve(rf.path)
                                Net.downloadResumable(rf, dest, counter)
                                index.put(rf.path, dest, rf.sha256)
                                index.save()
                                filesDone.incrementAndGet()
                            }
                        }
                    }.awaitAll()
                } finally {
                    ticker.cancel()
                }
            }

            index.dataVersion = manifest.dataVersion
            index.save()
            onProgress(SyncProgress(Phase.DONE, totalBytes, totalBytes, 0, "", totalFiles, totalFiles))
        }
}
