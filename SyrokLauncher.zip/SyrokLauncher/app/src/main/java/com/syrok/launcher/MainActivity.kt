package com.syrok.launcher

import android.animation.ObjectAnimator
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.syrok.launcher.data.CacheIndex
import com.syrok.launcher.data.GameStorage
import com.syrok.launcher.data.Manifest
import com.syrok.launcher.data.ManifestRepository
import com.syrok.launcher.net.ApkUpdater
import com.syrok.launcher.net.GameSync
import com.syrok.launcher.net.Phase
import com.syrok.launcher.net.ServerQuery
import com.syrok.launcher.net.ServerStatus
import com.syrok.launcher.net.SyncProgress
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private enum class State { LOADING, ERROR, NEED_APK, APK_DOWNLOADING, DOWNLOADING, PAUSED, READY }

    private lateinit var storage: GameStorage
    private lateinit var index: CacheIndex
    private lateinit var prefs: SharedPreferences

    private lateinit var logo: ImageView
    private lateinit var card: View
    private lateinit var newsText: TextView
    private lateinit var nickInput: EditText
    private lateinit var statusText: TextView
    private lateinit var percentText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var detailText: TextView
    private lateinit var mainButton: TextView
    private lateinit var onlineDot: View
    private lateinit var onlineText: TextView

    private var manifest: Manifest? = null
    private var state = State.LOADING
    private var job: Job? = null
    private var generation = 0
    private var lastProgress: SyncProgress? = null
    private var errorText: String = ""
    private var offlineMode = false

    private val abi: String get() = if (Process.is64Bit()) "arm64-v8a" else "armeabi-v7a"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        hideSystemBars()

        storage = GameStorage(this)
        index = CacheIndex(storage.indexFile)
        prefs = getSharedPreferences("syrok", MODE_PRIVATE)

        logo = findViewById(R.id.logo)
        card = findViewById(R.id.card)
        newsText = findViewById(R.id.newsText)
        nickInput = findViewById(R.id.nickInput)
        statusText = findViewById(R.id.statusText)
        percentText = findViewById(R.id.percentText)
        progressBar = findViewById(R.id.progress)
        detailText = findViewById(R.id.detailText)
        mainButton = findViewById(R.id.mainButton)
        onlineDot = findViewById(R.id.onlineDot)
        onlineText = findViewById(R.id.onlineText)

        nickInput.setText(prefs.getString(PREF_NICK, ""))
        mainButton.setOnClickListener { onMainClick() }
        findViewById<View>(R.id.discordBtn).setOnClickListener { openUrl(LauncherConfig.DISCORD_URL) }
        findViewById<View>(R.id.tgBtn).setOnClickListener { openUrl(LauncherConfig.TG_URL) }
        findViewById<View>(R.id.vkBtn).setOnClickListener { openUrl(LauncherConfig.VK_URL) }
        findViewById<TextView>(R.id.versionText).text = "v" + BuildConfig.VERSION_NAME
        for (id in intArrayOf(R.id.mainButton, R.id.discordBtn, R.id.tgBtn, R.id.vkBtn)) {
            addPressEffect(findViewById(id))
        }
        findViewById<View>(R.id.clearBtn).setOnClickListener { confirmClearCache() }

        animateIntro()
        startServerPolling()
        loadManifest()
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    // ───────────────────────── манифест ─────────────────────────

    private fun loadManifest() {
        job?.cancel()
        val gen = ++generation
        setState(State.LOADING)
        job = lifecycleScope.launch {
            val result = ManifestRepository.fetch(this@MainActivity, abi)
            if (gen != generation) return@launch
            val fresh = result.getOrNull()
            if (fresh != null) {
                offlineMode = false
                onManifest(fresh)
                return@launch
            }
            val cached = ManifestRepository.cached(this@MainActivity, abi)
            if (cached != null && index.allValid(cached.files) { storage.resolve(it.path) }) {
                // Нет сети, но всё уже установлено — можно играть
                offlineMode = true
                manifest = cached
                showNews(cached)
                setState(State.READY)
            } else {
                errorText = "Нет связи с сервером обновлений.\n${result.exceptionOrNull()?.message.orEmpty()}"
                setState(State.ERROR)
            }
        }
    }

    private fun onManifest(m: Manifest) {
        manifest = m
        showNews(m)
        val apk = m.apk
        if (apk != null && apk.versionCode > currentVersionCode()) {
            setState(State.NEED_APK)   // сначала обновляем сам лаунчер
            return
        }
        startSync()                    // автоустановка / автообновление игры
    }

    private fun showNews(m: Manifest) {
        newsText.text = m.changelog.ifBlank { "Добро пожаловать на ${LauncherConfig.PROJECT_NAME}!" }
    }

    // ───────────────────────── загрузка игры ─────────────────────────

    private fun startSync() {
        val m = manifest ?: return loadManifest()
        job?.cancel()
        val gen = ++generation
        lastProgress = null
        setState(State.DOWNLOADING)
        job = lifecycleScope.launch {
            try {
                GameSync(storage, index).run(m) { p ->
                    runOnUiThread {
                        if (gen == generation) {
                            lastProgress = p
                            render()
                        }
                    }
                }
                if (gen == generation) setState(State.READY)
            } catch (e: CancellationException) {
                if (gen == generation) setState(State.PAUSED)
                throw e
            } catch (e: Exception) {
                if (gen == generation) {
                    errorText = e.message ?: e.javaClass.simpleName
                    setState(State.ERROR)
                }
            }
        }
    }

    private fun updateLauncher() {
        val info = manifest?.apk ?: return
        job?.cancel()
        val gen = ++generation
        lastProgress = null
        setState(State.APK_DOWNLOADING)
        job = lifecycleScope.launch {
            try {
                val apk = ApkUpdater.download(storage, info) { done, total ->
                    runOnUiThread {
                        if (gen == generation) {
                            lastProgress = SyncProgress(Phase.DOWNLOADING, done, total, 0, "launcher.apk", 0, 1)
                            render()
                        }
                    }
                }
                if (gen != generation) return@launch
                if (!ApkUpdater.install(this@MainActivity, apk)) {
                    Toast.makeText(
                        this@MainActivity,
                        "Разреши установку из этого источника и нажми кнопку ещё раз",
                        Toast.LENGTH_LONG,
                    ).show()
                }
                setState(State.NEED_APK)
            } catch (e: CancellationException) {
                if (gen == generation) setState(State.NEED_APK)
                throw e
            } catch (e: Exception) {
                if (gen == generation) {
                    errorText = "Не удалось скачать обновление лаунчера:\n${e.message.orEmpty()}"
                    setState(State.ERROR)
                }
            }
        }
    }

    // ───────────────────────── кнопки ─────────────────────────

    private fun onMainClick() {
        when (state) {
            State.READY -> play()
            State.DOWNLOADING -> job?.cancel()                 // пауза
            State.APK_DOWNLOADING -> job?.cancel()
            State.PAUSED -> startSync()
            State.NEED_APK -> updateLauncher()
            State.ERROR -> if (manifest == null) loadManifest() else if (manifest?.apk?.let { it.versionCode > currentVersionCode() } == true) updateLauncher() else startSync()
            State.LOADING -> Unit
        }
    }

    private fun play() {
        val nick = nickInput.text.toString().trim()
        if (!NICK_REGEX.matches(nick)) {
            nickInput.error = "3–20 символов: латиница, цифры и _ [ ] \$ = @ . ( )"
            return
        }
        val m = manifest ?: return
        val libs = m.loadOrder.map { storage.resolve(it) }
        val missing = libs.firstOrNull { !it.isFile }
        if (missing != null) {
            Toast.makeText(this, "Не найден файл: ${missing.name}. Нажми «Очистить кэш».", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString(PREF_NICK, nick).apply()
        startActivity(
            Intent(this, GameActivity::class.java)
                .putExtra(GameActivity.EXTRA_NICK, nick)
                .putExtra(GameActivity.EXTRA_IP, m.serverIp)
                .putExtra(GameActivity.EXTRA_PORT, m.serverPort)
                .putExtra(GameActivity.EXTRA_ROOT, storage.externalRoot.absolutePath)
                .putExtra(GameActivity.EXTRA_LIBS, libs.map(File::getAbsolutePath).toTypedArray())
        )
    }

    private fun confirmClearCache() {
        AlertDialog.Builder(this)
            .setTitle("Очистить кэш?")
            .setMessage("Все игровые файлы будут удалены и скачаны заново.")
            .setPositiveButton("Очистить") { _, _ ->
                job?.cancel()
                generation++
                storage.clearAll()
                index.clear()
                loadManifest()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun openUrl(url: String) {
        if (url.isBlank()) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Не найдено приложение для открытия ссылки", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────────────────────── онлайн сервера ─────────────────────────

    private fun startServerPolling() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    val host = manifest?.serverIp ?: LauncherConfig.DEFAULT_SERVER_IP
                    val port = manifest?.serverPort ?: LauncherConfig.DEFAULT_SERVER_PORT
                    showServerStatus(ServerQuery.query(host, port))
                    delay(15_000)
                }
            }
        }
    }

    private fun showServerStatus(s: ServerStatus?) {
        val color = if (s != null) 0xFF3DDC84.toInt() else 0xFFE5484D.toInt()
        onlineDot.backgroundTintList = ColorStateList.valueOf(color)
        onlineText.text = if (s != null) "${s.players} / ${s.maxPlayers} онлайн · ${s.pingMs} мс" else "Сервер недоступен"
    }

    // ───────────────────────── отрисовка ─────────────────────────

    private fun setState(s: State) {
        state = s
        render()
    }

    private fun render() {
        val p = lastProgress
        val white = ContextCompat.getColor(this, R.color.text_primary)
        val red = ContextCompat.getColor(this, R.color.error)
        statusText.setTextColor(white)
        detailText.text = ""
        var buttonEnabled = true

        when (state) {
            State.LOADING -> {
                statusText.text = "Подключение к серверу обновлений…"
                setProgress(0f)
                buttonEnabled = false
                mainButton.text = "ПОДОЖДИТЕ"
            }
            State.ERROR -> {
                statusText.text = errorText
                statusText.setTextColor(red)
                mainButton.text = "ПОВТОРИТЬ"
            }
            State.NEED_APK -> {
                statusText.text = "Доступно обновление лаунчера ${manifest?.apk?.versionName.orEmpty()}"
                setProgress(0f)
                mainButton.text = "ОБНОВИТЬ ЛАУНЧЕР"
            }
            State.APK_DOWNLOADING, State.DOWNLOADING -> {
                val isApk = state == State.APK_DOWNLOADING
                if (p == null || p.phase == Phase.CHECKING) {
                    statusText.text = if (p == null) "Подготовка…" else "Проверка файлов… (${p.filesDone}/${p.filesTotal})"
                    setProgress(if (p != null && p.totalBytes > 0) p.doneBytes.toFloat() / p.totalBytes else 0f)
                } else {
                    val fraction = if (p.totalBytes > 0) p.doneBytes.toFloat() / p.totalBytes else 0f
                    statusText.text = if (isApk) "Загрузка обновления лаунчера" else "Загрузка файлов игры"
                    setProgress(fraction)
                    val speed = if (p.speedBps > 0) " · ${p.speedBps.toMegabytes()} МБ/с" else ""
                    val eta = if (p.speedBps > 0) " · осталось ${formatEta((p.totalBytes - p.doneBytes) / p.speedBps)}" else ""
                    detailText.text = "${p.doneBytes.toMegabytes()} / ${p.totalBytes.toMegabytes()} МБ$speed$eta"
                }
                mainButton.text = "ПАУЗА"
            }
            State.PAUSED -> {
                statusText.text = "Загрузка приостановлена"
                if (p != null && p.totalBytes > 0) {
                    detailText.text = "${p.doneBytes.toMegabytes()} / ${p.totalBytes.toMegabytes()} МБ"
                }
                mainButton.text = "ПРОДОЛЖИТЬ"
            }
            State.READY -> {
                statusText.text = if (offlineMode) "Офлайн-режим: обновления не проверялись" else "Всё готово к игре"
                setProgress(1f)
                mainButton.text = "ИГРАТЬ"
            }
        }

        mainButton.isEnabled = buttonEnabled
        mainButton.setBackgroundResource(if (buttonEnabled) R.drawable.bg_button else R.drawable.bg_button_disabled)
    }

    private fun setProgress(fraction: Float) {
        val f = fraction.coerceIn(0f, 1f)
        progressBar.progress = (f * 1000).toInt()
        percentText.text = if (state == State.LOADING) "" else "${(f * 100).toInt()}%"
    }

    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun addPressEffect(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    private fun animateIntro() {
        ObjectAnimator.ofFloat(findViewById<View>(R.id.glow), View.ALPHA, 0.45f, 1f).apply {
            duration = 2200
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
        ObjectAnimator.ofFloat(onlineDot, View.ALPHA, 0.35f, 1f).apply {
            duration = 900
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
        ObjectAnimator.ofFloat(logo, View.TRANSLATION_Y, 0f, -14f).apply {
            duration = 2200
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        card.alpha = 0f
        card.translationX = 80f
        card.animate().alpha(1f).translationX(0f).setDuration(700)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        logo.alpha = 0f
        logo.animate().alpha(1f).setDuration(900).start()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun currentVersionCode(): Long =
        PackageInfoCompat.getLongVersionCode(packageManager.getPackageInfo(packageName, 0))

    companion object {
        private const val PREF_NICK = "nick"
        private val NICK_REGEX = Regex("^[A-Za-z0-9_\\[\\]\$=@.()]{3,20}\$")
    }
}
