package com.syrok.launcher.data

import android.content.Context
import com.syrok.launcher.LauncherConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class RemoteFile(val path: String, val url: String, val size: Long, val sha256: String)

data class ApkInfo(
    val versionCode: Long,
    val versionName: String,
    val url: String,
    val size: Long,
    val sha256: String,
)

data class Manifest(
    val dataVersion: Int,
    val files: List<RemoteFile>,
    val loadOrder: List<String>,
    val serverIp: String,
    val serverPort: Int,
    val apk: ApkInfo?,
    val changelog: String,
)

private val SHA_REGEX = Regex("[0-9a-f]{64}")

object ManifestParser {

    /** [abi] = "arm64-v8a" или "armeabi-v7a": файлы с другим "abi" отбрасываются. */
    fun parse(text: String, abi: String): Manifest {
        val o = JSONObject(text)

        val arr = o.optJSONArray("files") ?: JSONArray()
        val files = ArrayList<RemoteFile>()
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            val fileAbi = f.optString("abi", "")
            if (fileAbi.isNotEmpty() && fileAbi != abi) continue

            val url = f.getString("url")
            require(url.startsWith("https://")) { "Разрешён только https: $url" }
            val sha = f.getString("sha256").lowercase()
            require(SHA_REGEX.matches(sha)) { "Некорректный sha256 у ${f.getString("path")}" }
            val size = f.getLong("size")
            require(size > 0) { "Некорректный размер у ${f.getString("path")}" }
            files += RemoteFile(f.getString("path"), url, size, sha)
        }

        val orderArr = o.optJSONArray("loadOrder")
        val order = if (orderArr == null) emptyList()
        else List(orderArr.length()) { orderArr.getString(it).replace("{abi}", abi) }

        val server = o.optJSONObject("server")

        val apk = o.optJSONObject("apk")?.let {
            val url = it.getString("url")
            require(url.startsWith("https://")) { "Разрешён только https: $url" }
            ApkInfo(
                versionCode = it.getLong("versionCode"),
                versionName = it.optString("versionName", ""),
                url = url,
                size = it.getLong("size"),
                sha256 = it.getString("sha256").lowercase(),
            )
        }

        return Manifest(
            dataVersion = o.optInt("dataVersion", 1),
            files = files,
            loadOrder = order,
            serverIp = server?.optString("ip", LauncherConfig.DEFAULT_SERVER_IP)
                ?: LauncherConfig.DEFAULT_SERVER_IP,
            serverPort = server?.optInt("port", LauncherConfig.DEFAULT_SERVER_PORT)
                ?: LauncherConfig.DEFAULT_SERVER_PORT,
            apk = apk,
            changelog = o.optString("changelog", ""),
        )
    }
}

object ManifestRepository {

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "syrok/manifest.json")

    suspend fun fetch(ctx: Context, abi: String): Result<Manifest> = withContext(Dispatchers.IO) {
        runCatching {
            val base = LauncherConfig.MANIFEST_URL
            val sep = if (base.contains("?")) "&" else "?"
            val url = URL(base + sep + "t=" + System.currentTimeMillis())
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                useCaches = false
            }
            try {
                check(conn.responseCode == 200) { "HTTP ${conn.responseCode}" }
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val manifest = ManifestParser.parse(text, abi)
                cacheFile(ctx).apply { parentFile?.mkdirs() }.writeText(text)
                manifest
            } finally {
                conn.disconnect()
            }
        }
    }

    /** Последний успешно загруженный манифест — для офлайн-режима. */
    fun cached(ctx: Context, abi: String): Manifest? = runCatching {
        ManifestParser.parse(cacheFile(ctx).readText(), abi)
    }.getOrNull()
}
