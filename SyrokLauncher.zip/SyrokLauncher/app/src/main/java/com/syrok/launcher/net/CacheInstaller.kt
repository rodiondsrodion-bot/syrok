package com.syrok.launcher.net

import android.os.SystemClock
import com.syrok.launcher.BuildConfig
import com.syrok.launcher.LauncherConfig
import com.syrok.launcher.data.GameStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import java.util.zip.ZipException
import java.util.zip.ZipFile

/**
 * Скачивает один zip с кэшем игры (LauncherConfig.CACHE_URL) и распаковывает его в папку игры.
 * Без проверки sha256: качаем -> распаковываем -> готово. Есть докачка после обрыва.
 */
object CacheInstaller {

    private const val RETRIES = 4

    private fun marker(storage: GameStorage): Pair<Int, Int> = runCatching {
        val (v, d) = storage.cacheMarker.readText().trim().split(":")
        v.toInt() to d.toInt()
    }.getOrDefault(0 to 0)

    /** Сколько архивов уже распаковано для текущей CACHE_VERSION. */
    private fun partsDone(storage: GameStorage): Int =
        marker(storage).let { if (it.first == LauncherConfig.CACHE_VERSION) it.second else 0 }

    fun isInstalled(storage: GameStorage): Boolean =
        partsDone(storage) >= LauncherConfig.CACHE_URLS.size

    suspend fun install(storage: GameStorage, onProgress: (SyncProgress) -> Unit) =
        withContext(Dispatchers.IO) {
            val urls = LauncherConfig.CACHE_URLS
            for (idx in partsDone(storage) until urls.size) {
                val zip = File(storage.updatesDir, "cache_$idx.zip")
                val part = File(storage.updatesDir, "cache_$idx.zip.part")

                if (!zip.isFile) download(urls[idx], part, zip, storage, idx, urls.size, onProgress)
                val head = zip.inputStream().use { i -> ByteArray(4).also { i.read(it) } }
                if (head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte()) {
                    val size = zip.length()
                    val text = zip.inputStream().use { i -> ByteArray(40).let { b -> String(b, 0, maxOf(i.read(b), 0)) } }
                    zip.delete()
                    throw IOException("Часть ${idx + 1}: скачан не zip (${size / 1048576} МБ, начало файла: ${text.filter { it.code in 32..126 }})")
                }
                try {
                    unpack(zip, storage, onProgress)
                } catch (e: ZipException) {
                    val size = zip.length()
                    zip.delete()   // битый архив — при повторе скачается заново
                    throw IOException(
                        "Не удалось распаковать архив (часть ${idx + 1}, скачано ${size / 1048576} МБ): ${e.message}"
                    )
                }
                storage.cacheMarker.apply { parentFile?.mkdirs() }
                    .writeText("${LauncherConfig.CACHE_VERSION}:${idx + 1}")
                zip.delete()
            }
        }

    // ───────────────────────── скачивание ─────────────────────────

    private suspend fun download(
        url: String, part: File, zip: File, storage: GameStorage, idx: Int, n: Int, onProgress: (SyncProgress) -> Unit,
    ) {
        var attempt = 0
        while (true) {
            try {
                downloadOnce(url, part, zip, storage, idx, n, onProgress)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: NoSpaceException) {
                throw e
            } catch (e: IOException) {
                attempt++
                if (attempt >= RETRIES) throw e
                delay(1500L * attempt)
            }
        }
    }

    private class Resolved(val href: String, val size: Long, val name: String)

    private fun getJson(api: String, what: String): JSONObject {
        val c = (URL(api).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
        }
        try {
            if (c.responseCode != 200) {
                throw IOException("Яндекс Диск ($what): HTTP ${c.responseCode}. Проверь ссылку и «Доступ по ссылке»")
            }
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    /** Публичная ссылка Яндекс Диска -> временная прямая ссылка на скачивание (официальный API). */
    private fun resolveUrl(url: String): Resolved {
        if (!url.contains("disk.yandex.") && !url.contains("yadi.sk")) return Resolved(url, -1, "")
        val key = URLEncoder.encode(url, "UTF-8")
        val meta = getJson("https://cloud-api.yandex.net/v1/disk/public/resources?public_key=$key&limit=1", "инфо")
        if (meta.optString("type") == "dir") {
            throw NoSpaceException("Ссылка ведёт на ПАПКУ «${meta.optString("name")}». Нужна ссылка на сам .zip файл")
        }
        val href = getJson("https://cloud-api.yandex.net/v1/disk/public/resources/download?public_key=$key", "скачивание")
            .getString("href")
        return Resolved(href, meta.optLong("size", -1), meta.optString("name"))
    }

    private suspend fun downloadOnce(
        url: String, part: File, zip: File, storage: GameStorage, idx: Int, n: Int, onProgress: (SyncProgress) -> Unit,
    ) {
        part.parentFile?.mkdirs()
        var offset = part.length()

        val resolved = resolveUrl(url)
        val conn = (URL(resolved.href).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "SyrokLauncher/${BuildConfig.VERSION_NAME}")
            if (offset > 0) setRequestProperty("Range", "bytes=$offset-")
        }

        try {
            val append: Boolean
            when (val code = conn.responseCode) {
                206 -> append = true
                200 -> {            // сервер отдал файл целиком — качаем сначала
                    offset = 0
                    append = false
                }
                416 -> {            // докачивать нечего — файл уже полный
                    if (part.length() > 0) {
                        zip.delete()
                        if (!part.renameTo(zip)) throw IOException("Не удалось сохранить кэш")
                        return
                    }
                    throw IOException("HTTP 416")
                }
                else -> throw IOException("Не удалось скачать кэш: HTTP $code")
            }

            val len = conn.contentLengthLong
            val total = if (len > 0) offset + len else 0L
            if (total > 0) {
                val need = total - offset
                // zip + распакованное: берём с запасом
                if (storage.updatesDir.usableSpace < need + 50L * 1024 * 1024) {
                    throw NoSpaceException("Недостаточно места для загрузки кэша")
                }
            }

            var done = offset
            var lastT = SystemClock.elapsedRealtime()
            var lastBytes = done
            var speed = 0L

            FileOutputStream(part, append).use { out ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        currentCoroutineContext().ensureActive()
                        val t = SystemClock.elapsedRealtime()
                        if (t - lastT >= 300) {
                            val inst = (done - lastBytes) * 1000 / (t - lastT)
                            speed = if (speed == 0L) inst else (speed * 7 + inst * 3) / 10
                            lastT = t
                            lastBytes = done
                            onProgress(SyncProgress(Phase.DOWNLOADING, done, total, speed, "cache_${idx + 1}.zip", idx, n))
                        }
                    }
                }
            }
            if (total > 0 && part.length() != total) throw IOException("Загрузка кэша оборвалась")
            if (resolved.size > 0 && part.length() != resolved.size) {
                part.delete()
                throw IOException(
                    "Скачано ${part.length() / 1048576} МБ, а файл «${resolved.name}» на Диске ${resolved.size / 1048576} МБ"
                )
            }
        } finally {
            conn.disconnect()
        }

        zip.delete()
        if (!part.renameTo(zip)) throw IOException("Не удалось сохранить кэш")
    }

    // ───────────────────────── распаковка ─────────────────────────

    private suspend fun unpack(zip: File, storage: GameStorage, onProgress: (SyncProgress) -> Unit) {
        ZipFile(zip).use { zf ->
            val entries = zf.entries().toList().filter { !it.isDirectory }
            val total = entries.sumOf { maxOf(it.size, 0L) }
            if (storage.externalRoot.usableSpace < total + 50L * 1024 * 1024) {
                throw NoSpaceException("Недостаточно места для распаковки кэша")
            }

            var done = 0L
            var lastT = 0L
            var cur = ""
            try {
            for ((i, e) in entries.withIndex()) {
                cur = e.name
                currentCoroutineContext().ensureActive()
                val name = e.name.replace('\\', '/').trimStart('/')
                if (name.isEmpty() || name.startsWith("__MACOSX/") || name.endsWith(".DS_Store")) continue

                val dest = try {
                    storage.resolve(name)
                } catch (ex: IllegalArgumentException) {
                    continue      // подозрительный путь (../) — пропускаем
                }
                dest.parentFile?.mkdirs()
                if (dest.exists()) {
                    dest.setWritable(true)
                    dest.delete()
                }

                zf.getInputStream(e).use { input ->
                    FileOutputStream(dest).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val t = SystemClock.elapsedRealtime()
                            if (t - lastT >= 300) {
                                lastT = t
                                currentCoroutineContext().ensureActive()
                                onProgress(SyncProgress(Phase.UNPACKING, done, total, 0, name, i, entries.size))
                            }
                        }
                    }
                }
                // Android 14+: динамически загружаемые библиотеки обязаны быть read-only
                if (dest.name.endsWith(".so")) dest.setReadOnly()
            }
            } catch (e: ZipException) {
                throw ZipException("файл «$cur»: ${e.message}")
            }
            onProgress(SyncProgress(Phase.UNPACKING, total, total, 0, "", entries.size, entries.size))
        }
    }
}
