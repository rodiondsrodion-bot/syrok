package com.syrok.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin
import kotlin.random.Random

/** Лёгкая анимация: оранжевые искры поднимаются вверх на фоне лаунчера. */
class EmbersView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    private class Particle(
        var x: Float, var y: Float,       // 0..1 (доля экрана)
        val radius: Float,                // dp
        val speed: Float,                 // доля высоты в секунду
        val sway: Float,
        val phase: Float,
        val color: Int,
    )

    private val rnd = Random(System.nanoTime())
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particles = ArrayList<Particle>()
    private var last = 0L
    private var time = 0f

    init {
        repeat(36) { particles += spawn(initial = true) }
    }

    private fun spawn(initial: Boolean): Particle {
        val mix = rnd.nextFloat()
        val r = (247 + (224 - 247) * mix).toInt()
        val g = (134 + (32 - 134) * mix).toInt()
        val b = (31 + (28 - 31) * mix).toInt()
        return Particle(
            x = rnd.nextFloat(),
            y = if (initial) rnd.nextFloat() else 1.05f + rnd.nextFloat() * 0.1f,
            radius = 1f + rnd.nextFloat() * 2.2f,
            speed = 0.03f + rnd.nextFloat() * 0.07f,
            sway = 0.01f + rnd.nextFloat() * 0.02f,
            phase = rnd.nextFloat() * 6.28f,
            color = Color.rgb(r, g, b),
        )
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime() / 1_000_000
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        time += dt

        val w = width.toFloat()
        val h = height.toFloat()
        for (i in particles.indices) {
            val p = particles[i]
            p.y -= p.speed * dt
            if (p.y < -0.05f) {
                particles[i] = spawn(initial = false)
                continue
            }
            val px = (p.x + sin(time * 0.8f + p.phase) * p.sway) * w
            val py = p.y * h
            // плавно гаснут к верху, мерцают
            val fade = (p.y.coerceIn(0f, 1f)).let { if (it < 0.25f) it / 0.25f else 1f }
            val twinkle = 0.65f + 0.35f * sin(time * 3f + p.phase)
            val a = (fade * twinkle * 255).toInt().coerceIn(0, 255)

            paint.color = p.color
            paint.alpha = a / 4
            canvas.drawCircle(px, py, p.radius * density * 2.6f, paint)
            paint.alpha = a
            canvas.drawCircle(px, py, p.radius * density, paint)
        }
        postInvalidateOnAnimation()
    }
}
