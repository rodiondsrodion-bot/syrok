package com.syrok.launcher.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Где лежат файлы:
 *  • *.so      -> внутренняя память (/data/data/<pkg>/files/syrok/game): с внешней памяти
 *                 dlopen на многих устройствах не работает (noexec);
 *  • остальное -> Android/data/<pkg>/files/syrok/game (не нужны разрешения на память).
 */
class GameStorage(private val ctx: Context) {

    val internalRoot: File = File(ctx.filesDir, "syrok/game").apply { mkdirs() }
    val externalRoot: File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "syrok/game").apply { mkdirs() }
    val indexFile: File = File(ctx.filesDir, "syrok/cache_index.json")
    /** Отметка «zip с кэшем уже распакован» (внутри — номер CACHE_VERSION). */
    val cacheMarker: File = File(ctx.filesDir, "syrok/cache_installed")

    val updatesDir: File
        get() = (ctx.getExternalFilesDir("updates") ?: File(ctx.filesDir, "updates")).apply { mkdirs() }

    fun baseFor(path: String): File = if (path.endsWith(".so")) internalRoot else externalRoot

    /** Путь из манифеста -> файл. Защита от «../» и абсолютных путей. */
    fun resolve(path: String): File {
        val base = baseFor(path)
        val f = File(base, path).canonicalFile
        require(f.path.startsWith(base.canonicalPath + File.separator)) { "Недопустимый путь в манифесте: $path" }
        return f
    }

    /** Библиотеки для загрузки, если в манифесте нет loadOrder: сначала вспомогательные, затем libGTASA, затем libsamp. */
    fun findLibs(abi: String): List<File> {
        val otherAbis = listOf("arm64-v8a", "armeabi-v7a", "armeabi", "x86", "x86_64").filter { it != abi }
        fun rank(f: File) = when (f.name) { "libGTASA.so" -> 1; "libsamp.so" -> 2; else -> 0 }
        return internalRoot.walkTopDown()
            .filter { it.isFile && it.name.endsWith(".so") }
            .filter { f ->
                val p = "/" + f.relativeTo(internalRoot).path.replace('\\', '/') + "/"
                otherAbis.none { p.contains("/$it/") }
            }
            .sortedWith(compareBy({ rank(it) }, { it.path }))
            .toList()
    }

    fun clearAll() {
        internalRoot.deleteRecursively()
        externalRoot.deleteRecursively()
        indexFile.delete()
        cacheMarker.delete()
        File(updatesDir, "cache.zip").delete()
        File(updatesDir, "cache.zip.part").delete()
        internalRoot.mkdirs()
        externalRoot.mkdirs()
    }
}

/** Кэш проверенных файлов: чтобы не считать sha256 у гигабайтов при каждом запуске. */
class CacheIndex(private val file: File) {

    private data class Entry(val size: Long, val mtime: Long, val sha: String)

    private val map = ConcurrentHashMap<String, Entry>()
    var dataVersion: Int = 0

    init {
        runCatching {
            if (file.isFile) {
                val o = JSONObject(file.readText())
                dataVersion = o.optInt("dataVersion", 0)
                val files = o.getJSONObject("files")
                for (k in files.keys()) {
                    val e = files.getJSONObject(k)
                    map[k] = Entry(e.getLong("size"), e.getLong("mtime"), e.getString("sha"))
                }
            }
        }
    }

    fun isValid(rf: RemoteFile, f: File): Boolean {
        val e = map[rf.path] ?: return false
        return f.isFile && f.length() == rf.size && e.size == rf.size &&
                e.mtime == f.lastModified() && e.sha.equals(rf.sha256, ignoreCase = true)
    }

    fun allValid(files: List<RemoteFile>, resolver: (RemoteFile) -> File): Boolean =
        files.all { isValid(it, resolver(it)) }

    fun put(path: String, f: File, sha: String) {
        map[path] = Entry(f.length(), f.lastModified(), sha)
    }

    fun remove(path: String) {
        map.remove(path)
    }

    fun paths(): Set<String> = map.keys.toSet()

    fun clear() {
        map.clear()
        dataVersion = 0
        file.delete()
    }

    @Synchronized
    fun save() {
        runCatching {
            val files = JSONObject()
            for ((k, e) in map) {
                files.put(k, JSONObject().put("size", e.size).put("mtime", e.mtime).put("sha", e.sha))
            }
            file.parentFile?.mkdirs()
            file.writeText(JSONObject().put("dataVersion", dataVersion).put("files", files).toString())
        }
    }
}

fun File.sha256Hex(): String {
    val digest = MessageDigest.getInstance("SHA-256")
    inputStream().use { input ->
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            digest.update(buf, 0, n)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}
