package com.syrok.launcher

import android.app.Activity

/** Тонкая обёртка над libsyroklauncher.so (см. app/src/main/cpp/syrok.cpp). */
object NativeBridge {

    fun ensureLoaded(): Boolean = try {
        System.loadLibrary("syroklauncher")
        true
    } catch (e: UnsatisfiedLinkError) {
        false
    }

    @JvmStatic external fun nativeInit(nick: String, ip: String, port: Int, root: String)

    /** Возвращает null при успехе, иначе текст ошибки. */
    @JvmStatic external fun nativeLoadLibraries(paths: Array<String>): String?

    /** Возвращает null при успехе, иначе текст ошибки. */
    @JvmStatic external fun nativeStart(activity: Activity): String?

    @JvmStatic external fun nativeVersion(): String
}
