package com.syrok.launcher

import java.util.Locale

fun Long.toMegabytes(): String = String.format(Locale.US, "%.1f", this / 1048576.0)

fun formatEta(seconds: Long): String = when {
    seconds < 0 -> ""
    seconds < 60 -> "$seconds с"
    seconds < 3600 -> "${seconds / 60} мин ${seconds % 60} с"
    else -> "${seconds / 3600} ч ${(seconds % 3600) / 60} мин"
}
