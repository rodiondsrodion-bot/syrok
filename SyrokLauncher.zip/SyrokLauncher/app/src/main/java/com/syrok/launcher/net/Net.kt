package com.syrok.launcher.net

import com.syrok.launcher.BuildConfig
import com.syrok.launcher.data.RemoteFile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicLong

object Net {

    private const val RETRIES = 4

    /**
     * Скачивает файл с докачкой (HTTP Range), проверяет sha256 и атомарно кладёт на место.
     * [counter] увеличивается на каждый записанный байт (для общего прогресса).
     * Инвариант: к началу попытки в counter уже учтена длина имеющегося .part.
     */
    suspend fun downloadResumable(rf: RemoteFile, dest: File, counter: AtomicLong) {
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        var attempt = 0
        while (true) {
            try {
                downloadOnce(rf, dest, part, counter)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                attempt++
                if (attempt >= RETRIES) throw e
                delay(1500L * attempt)
            }
        }
    }

    private suspend fun downloadOnce(rf: RemoteFile, dest: File, part: File, counter: AtomicLong) {
        var offset = part.length()
        if (offset > rf.size) {
            part.delete()
            counter.addAndGet(-offset)
            offset = 0
        }

        val conn = (URL(rf.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "SyrokLauncher/${BuildConfig.VERSION_NAME}")
            if (offset > 0) setRequestProperty("Range", "bytes=$offset-")
        }

        val digest = MessageDigest.getInstance("SHA-256")
        try {
            val append: Boolean
            when (val code = conn.responseCode) {
                206 -> append = true
                200 -> {
                    // сервер не умеет Range — качаем сначала
                    if (offset > 0) {
                        counter.addAndGet(-offset)
                        offset = 0
                    }
                    append = false
                }
                416 -> {
                    part.delete()
                    counter.addAndGet(-offset)
                    throw IOException("HTTP 416, перекачиваем ${rf.path}")
                }
                else -> throw IOException("HTTP $code для ${rf.path}")
            }

            // Уже скачанный кусок тоже должен попасть в хэш
            if (append && offset > 0) {
                part.inputStream().use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        digest.update(buf, 0, n)
                        currentCoroutineContext().ensureActive()
                    }
                }
            }

            FileOutputStream(part, append).use { out ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        digest.update(buf, 0, n)
                        counter.addAndGet(n.toLong())
                        currentCoroutineContext().ensureActive()
                    }
                }
            }
        } finally {
            conn.disconnect()
        }

        if (part.length() != rf.size) {
            throw IOException("Размер не совпал у ${rf.path}: ${part.length()} из ${rf.size}")
        }
        val actual = digest.digest().joinToString("") { "%02x".format(it) }
        if (!actual.equals(rf.sha256, ignoreCase = true)) {
            part.delete()
            counter.addAndGet(-rf.size)
            throw IOException("Контрольная сумма не совпала: ${rf.path}")
        }

        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) throw IOException("Не удалось сохранить ${rf.path}")
        // Android 14+: динамически загружаемые библиотеки обязаны быть read-only
        if (dest.name.endsWith(".so")) dest.setReadOnly()
    }
}
