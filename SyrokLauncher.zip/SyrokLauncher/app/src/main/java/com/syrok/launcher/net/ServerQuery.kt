package com.syrok.launcher.net

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

data class ServerStatus(val players: Int, val maxPlayers: Int, val name: String, val pingMs: Int)

/** Стандартный UDP-запрос статуса SA-MP / open.mp (опкод 'i'). */
object ServerQuery {

    suspend fun query(host: String, port: Int, timeoutMs: Int = 2000): ServerStatus? =
        withContext(Dispatchers.IO) {
            try {
                val addr = InetAddress.getByName(host)
                if (addr !is Inet4Address) return@withContext null

                val req = ByteArray(11)
                "SAMP".toByteArray(Charsets.US_ASCII).copyInto(req, 0)
                addr.address.copyInto(req, 4)
                req[8] = (port and 0xFF).toByte()
                req[9] = ((port shr 8) and 0xFF).toByte()
                req[10] = 'i'.code.toByte()

                DatagramSocket().use { socket ->
                    socket.soTimeout = timeoutMs
                    val t0 = SystemClock.elapsedRealtime()
                    socket.send(DatagramPacket(req, req.size, addr, port))
                    val buf = ByteArray(1500)
                    val pkt = DatagramPacket(buf, buf.size)
                    socket.receive(pkt)
                    val ping = (SystemClock.elapsedRealtime() - t0).toInt()
                    parse(buf, pkt.length, ping)
                }
            } catch (e: Exception) {
                null
            }
        }

    private fun parse(data: ByteArray, length: Int, ping: Int): ServerStatus? {
        // 11 байт эхо заголовка, 1 опкод, 1 пароль, 2 игроков, 2 максимум, 4 длина имени, имя
        if (length < 20) return null
        val bb = ByteBuffer.wrap(data, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        val players = bb.getShort(12).toInt() and 0xFFFF
        val max = bb.getShort(14).toInt() and 0xFFFF
        val nameLen = bb.getInt(16)
        val name = if (nameLen in 0..(length - 20)) {
            String(data, 20, nameLen, Charset.forName("windows-1251"))
        } else ""
        return ServerStatus(players, max, name, ping)
    }
}
