package com.syrok.launcher

/** Все настройки проекта в одном месте. Поменяй под себя. */
object LauncherConfig {
    const val PROJECT_NAME = "Syrok Role Play"

    /** URL manifest.json на твоём хостинге/CDN (обязательно https). */
    const val MANIFEST_URL = "https://example.com/syrok/manifest.json"

    /** Запасные значения, если в манифесте нет блока "server". */
    const val DEFAULT_SERVER_IP = "127.0.0.1"
    const val DEFAULT_SERVER_PORT = 7777

    /** Оставь пустой строкой, если кнопка не нужна. */
    const val DISCORD_URL = "https://discord.gg/your-invite"
    const val VK_URL = "https://vk.com/your_group"

    /** Сколько файлов качать одновременно. */
    const val PARALLEL_DOWNLOADS = 3
}
