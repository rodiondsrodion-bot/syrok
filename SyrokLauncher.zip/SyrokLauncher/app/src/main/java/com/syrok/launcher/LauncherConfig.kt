package com.syrok.launcher

/** Все настройки проекта в одном месте. Поменяй под себя. */
object LauncherConfig {
    const val PROJECT_NAME = "Syrok Role Play"

    /**
     * Ссылка на manifest.json (https). Берётся из файла manifest_url.txt в корне GitHub-репозитория
     * (см. app/build.gradle.kts). Ссылки Dropbox с ?dl=0 автоматически превращаются в ?dl=1.
     */
    val MANIFEST_URL: String
        get() = BuildConfig.MANIFEST_URL.trim().replace("dl=0", "dl=1")

    /**
     * Zip-архивы с кэшем игры (можно несколько: каждый распаковывается в общую папку игры).
     * Поддерживаются прямые https-ссылки и публичные ссылки Яндекс Диска (disk.yandex.ru/d/...).
     * Ссылки Dropbox с dl=0 превращаются в dl=1.
     */
    val CACHE_URLS: List<String>
        get() = listOf(
            "https://disk.yandex.ru/d/7Ptu0x6Jde-IpA",
            "https://disk.yandex.ru/d/Z2W2Jiuv0iHodA",
        ).map { it.replace("dl=0", "dl=1") }

    /** Увеличь число, если выложил новый CacheGame.zip: лаунчер скачает и распакует его заново. */
    const val CACHE_VERSION = 2

    /** Запасные значения, если в манифесте нет блока "server". */
    const val DEFAULT_SERVER_IP = "127.0.0.1"
    const val DEFAULT_SERVER_PORT = 7777

    /** Ссылки на соцсети (кнопки слева в лаунчере). */
    const val DISCORD_URL = "https://discord.gg/vxRhxKG46p"
    const val TG_URL = "https://t.me/rpsyrok"
    const val VK_URL = "https://vk.ru/syrokroleplaycrmp"

    /** Сколько файлов качать одновременно. */
    const val PARALLEL_DOWNLOADS = 3
}
