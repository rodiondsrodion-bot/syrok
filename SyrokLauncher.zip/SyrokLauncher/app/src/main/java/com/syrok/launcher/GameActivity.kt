package com.syrok.launcher

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Экран игры. Работает в отдельном процессе (:game).
 * Грузит нативные библиотеки через JNI и запускает игру.
 */
class GameActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goImmersive()

        val nick = intent.getStringExtra(EXTRA_NICK).orEmpty()
        val ip = intent.getStringExtra(EXTRA_IP).orEmpty()
        val port = intent.getIntExtra(EXTRA_PORT, LauncherConfig.DEFAULT_SERVER_PORT)
        val root = intent.getStringExtra(EXTRA_ROOT).orEmpty()
        val libs = intent.getStringArrayExtra(EXTRA_LIBS) ?: emptyArray()

        if (!NativeBridge.ensureLoaded()) return fail("Не удалось загрузить libsyroklauncher.so")

        NativeBridge.nativeInit(nick, ip, port, root)
        NativeBridge.nativeLoadLibraries(libs)?.let { return fail(it) }
        NativeBridge.nativeStart(this)?.let { return fail(it) }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }

    @Suppress("DEPRECATION")
    private fun goImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun fail(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        finish()
    }

    companion object {
        const val EXTRA_NICK = "nick"
        const val EXTRA_IP = "ip"
        const val EXTRA_PORT = "port"
        const val EXTRA_ROOT = "root"
        const val EXTRA_LIBS = "libs"
    }
}
