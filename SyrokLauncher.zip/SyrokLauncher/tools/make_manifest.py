#!/usr/bin/env python3
"""
Генератор manifest.json для лаунчера Syrok Role Play (только стандартная библиотека Python).

Пример:
  python3 tools/make_manifest.py ./game_files https://cdn.example.com/syrok/files \
      --data-version 3 --server 1.2.3.4:7777 \
      --load-order "libs/{abi}/libGTASA.so" "libs/{abi}/libsamp.so" \
      --changelog "Версия 3: новая карта, фиксы." \
      --apk ./SyrokLauncher-release.apk --apk-url https://cdn.example.com/syrok/launcher.apk \
      --apk-version-code 2 --apk-version-name 1.0.1 \
      -o manifest.json

Структура папки game_files = структура на устройстве. Всё из неё нужно выложить по base-url.
Файлы в подпапках arm64-v8a/ или armeabi-v7a/ автоматически получают поле "abi".
"""
import argparse
import hashlib
import json
import os
import sys
from urllib.parse import quote

ABIS = ("arm64-v8a", "armeabi-v7a")


def sha256_of(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("folder", help="папка с игровыми файлами")
    p.add_argument("base_url", help="https-адрес, по которому лежит содержимое папки")
    p.add_argument("-o", "--output", default="manifest.json")
    p.add_argument("--data-version", type=int, default=1)
    p.add_argument("--server", help="ip:port игрового сервера")
    p.add_argument("--load-order", nargs="*", default=[], help="порядок загрузки .so, можно {abi}")
    p.add_argument("--changelog", default="", help="текст новостей (или @файл.txt)")
    p.add_argument("--apk", help="путь к новому APK лаунчера")
    p.add_argument("--apk-url")
    p.add_argument("--apk-version-code", type=int)
    p.add_argument("--apk-version-name", default="")
    a = p.parse_args()

    if not a.base_url.startswith("https://"):
        print("base_url должен начинаться с https://", file=sys.stderr)
        return 1
    if not os.path.isdir(a.folder):
        print(f"Нет такой папки: {a.folder}", file=sys.stderr)
        return 1

    files = []
    for root, dirs, names in os.walk(a.folder):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for name in sorted(names):
            if name.startswith(".") or name.endswith(".part"):
                continue
            full = os.path.join(root, name)
            rel = os.path.relpath(full, a.folder).replace(os.sep, "/")
            size = os.path.getsize(full)
            if size == 0:
                continue
            entry = {
                "path": rel,
                "url": a.base_url.rstrip("/") + "/" + quote(rel),
                "size": size,
                "sha256": sha256_of(full),
            }
            for abi in ABIS:
                if f"/{abi}/" in f"/{rel}":
                    entry["abi"] = abi
            files.append(entry)
            print(f"  + {rel} ({size} байт)")

    manifest = {"dataVersion": a.data_version, "files": files}
    if a.load_order:
        manifest["loadOrder"] = a.load_order
    if a.server:
        ip, _, port = a.server.partition(":")
        manifest["server"] = {"ip": ip, "port": int(port or 7777)}
    if a.changelog:
        manifest["changelog"] = open(a.changelog[1:], encoding="utf-8").read() if a.changelog.startswith("@") else a.changelog
    if a.apk:
        if not (a.apk_url and a.apk_version_code):
            print("Для --apk нужны --apk-url и --apk-version-code", file=sys.stderr)
            return 1
        manifest["apk"] = {
            "versionCode": a.apk_version_code,
            "versionName": a.apk_version_name,
            "url": a.apk_url,
            "size": os.path.getsize(a.apk),
            "sha256": sha256_of(a.apk),
        }

    with open(a.output, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(f"Готово: {a.output} ({len(files)} файлов)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
